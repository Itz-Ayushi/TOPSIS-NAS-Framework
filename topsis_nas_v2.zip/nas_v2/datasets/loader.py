"""
datasets/loader.py
------------------
Unified data-loading interface for all supported datasets.

Supported datasets
~~~~~~~~~~~~~~~~~~
cifar10           – 60k 32×32 RGB images, 10 classes  (torchvision)
mnist             – 70k 28×28 grayscale images, 10 digits (torchvision)
uci_wine          – 178 wine samples, 3 classes  (sklearn)
uci_breast_cancer – 569 tumour samples, 2 classes (sklearn)

UCI tabular datasets are wrapped in a lightweight TensorDataset and
exposed through identical DataLoader semantics as the image datasets,
so the training pipeline needs zero branching.

Returns
~~~~~~~
DatasetBundle(train_loader, test_loader, meta) where meta contains:
    input_shape  – (C, H, W) for images, (1, 1, n_features) for tabular
    num_classes  – int
    dataset_type – 'image' | 'tabular'
    name         – dataset identifier string
"""

import logging
from dataclasses import dataclass
from typing import Tuple

import numpy as np
import torch
from torch.utils.data import DataLoader, TensorDataset, random_split
import torchvision
import torchvision.transforms as T

log = logging.getLogger(__name__)

# Per-channel normalisation constants
_CIFAR_MEAN = (0.4914, 0.4822, 0.4465)
_CIFAR_STD  = (0.2470, 0.2435, 0.2616)
_MNIST_MEAN = (0.1307,)
_MNIST_STD  = (0.3081,)


@dataclass
class DatasetBundle:
    train_loader: DataLoader
    test_loader:  DataLoader
    input_shape:  Tuple          # (C, H, W)
    num_classes:  int
    dataset_type: str            # 'image' | 'tabular'
    name:         str


def load_dataset(
    name:        str,
    data_dir:    str  = "./data",
    batch_size:  int  = 64,
    num_workers: int  = 0,
) -> DatasetBundle:
    """
    Load any supported dataset by name and return a DatasetBundle.

    Args:
        name:        One of 'cifar10', 'mnist', 'uci_wine', 'uci_breast_cancer'.
        data_dir:    Root directory for torchvision downloads.
        batch_size:  Mini-batch size.
        num_workers: DataLoader subprocess workers (0 = main thread).

    Returns:
        DatasetBundle with train_loader, test_loader, and metadata.
    """
    name = name.lower()
    loaders = {
        "cifar10":           _load_cifar10,
        "mnist":             _load_mnist,
        "uci_wine":          _load_uci_wine,
        "uci_breast_cancer": _load_uci_breast_cancer,
    }
    if name not in loaders:
        raise ValueError(f"Unknown dataset '{name}'. Choose from: {list(loaders)}")

    log.info(f"  Loading dataset: {name}")
    bundle = loaders[name](data_dir, batch_size, num_workers)
    log.info(
        f"  {name}: input={bundle.input_shape}  "
        f"classes={bundle.num_classes}  type={bundle.dataset_type}"
    )
    return bundle


# ── Image datasets ────────────────────────────────────────────────────────────

def _load_cifar10(data_dir, batch_size, num_workers) -> DatasetBundle:
    train_tf = T.Compose([
        T.RandomCrop(32, padding=4),
        T.RandomHorizontalFlip(),
        T.ToTensor(),
        T.Normalize(_CIFAR_MEAN, _CIFAR_STD),
    ])
    test_tf = T.Compose([T.ToTensor(), T.Normalize(_CIFAR_MEAN, _CIFAR_STD)])

    train_ds = torchvision.datasets.CIFAR10(data_dir, True,  True, train_tf)
    test_ds  = torchvision.datasets.CIFAR10(data_dir, False, True, test_tf)

    pin = torch.cuda.is_available()
    return DatasetBundle(
        train_loader = DataLoader(train_ds, batch_size, shuffle=True,
                                  num_workers=num_workers, pin_memory=pin),
        test_loader  = DataLoader(test_ds,  batch_size, shuffle=False,
                                  num_workers=num_workers, pin_memory=pin),
        input_shape  = (3, 32, 32),
        num_classes  = 10,
        dataset_type = "image",
        name         = "cifar10",
    )


def _load_mnist(data_dir, batch_size, num_workers) -> DatasetBundle:
    train_tf = T.Compose([T.ToTensor(), T.Normalize(_MNIST_MEAN, _MNIST_STD)])
    test_tf  = T.Compose([T.ToTensor(), T.Normalize(_MNIST_MEAN, _MNIST_STD)])

    train_ds = torchvision.datasets.MNIST(data_dir, True,  True, train_tf)
    test_ds  = torchvision.datasets.MNIST(data_dir, False, True, test_tf)

    pin = torch.cuda.is_available()
    return DatasetBundle(
        train_loader = DataLoader(train_ds, batch_size, shuffle=True,
                                  num_workers=num_workers, pin_memory=pin),
        test_loader  = DataLoader(test_ds,  batch_size, shuffle=False,
                                  num_workers=num_workers, pin_memory=pin),
        input_shape  = (1, 28, 28),
        num_classes  = 10,
        dataset_type = "image",
        name         = "mnist",
    )


# ── UCI / tabular datasets ────────────────────────────────────────────────────

def _make_tabular_bundle(
    X: np.ndarray, y: np.ndarray,
    num_classes: int, name: str,
    batch_size: int, num_workers: int,
) -> DatasetBundle:
    """
    Helper: normalise features, split 80/20 train/test, wrap in DataLoaders.
    Tabular features are exposed as shape (1, 1, n_features) tensors so the
    same CNN 'flattens' them directly through the adaptive pool → FC head.
    """
    # Z-score normalisation across features
    mu, sigma = X.mean(0), X.std(0) + 1e-8
    X = (X - mu) / sigma

    X_t = torch.tensor(X, dtype=torch.float32).unsqueeze(1).unsqueeze(1)  # (N,1,1,F)
    y_t = torch.tensor(y, dtype=torch.long)

    full_ds = TensorDataset(X_t, y_t)
    n_train = int(0.8 * len(full_ds))
    n_test  = len(full_ds) - n_train
    train_ds, test_ds = random_split(
        full_ds, [n_train, n_test],
        generator=torch.Generator().manual_seed(42)
    )

    n_features = X.shape[1]
    return DatasetBundle(
        train_loader = DataLoader(train_ds, min(batch_size, n_train),
                                  shuffle=True,  num_workers=num_workers),
        test_loader  = DataLoader(test_ds,  min(batch_size, n_test),
                                  shuffle=False, num_workers=num_workers),
        input_shape  = (1, 1, n_features),
        num_classes  = num_classes,
        dataset_type = "tabular",
        name         = name,
    )


def _load_uci_wine(data_dir, batch_size, num_workers) -> DatasetBundle:
    from sklearn.datasets import load_wine
    data = load_wine()
    return _make_tabular_bundle(
        data.data, data.target, 3, "uci_wine", batch_size, num_workers
    )


def _load_uci_breast_cancer(data_dir, batch_size, num_workers) -> DatasetBundle:
    from sklearn.datasets import load_breast_cancer
    data = load_breast_cancer()
    return _make_tabular_bundle(
        data.data, data.target, 2, "uci_breast_cancer", batch_size, num_workers
    )
