"""utils/logger.py — Root logger setup."""
import logging, sys

def setup_logger(level: str = "INFO") -> None:
    logging.basicConfig(
        level=getattr(logging, level.upper(), logging.INFO),
        format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
        datefmt="%H:%M:%S",
        handlers=[logging.StreamHandler(sys.stdout)],
        force=True,
    )
    for noisy in ("PIL", "matplotlib", "urllib3", "sklearn"):
        logging.getLogger(noisy).setLevel(logging.WARNING)
