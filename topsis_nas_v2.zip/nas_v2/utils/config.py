"""
utils/config.py
---------------
Master configuration for the TOPSIS-Driven AutoML framework.
Covers all datasets, search strategies, metrics, and visualization options.
"""

import sys
import torch
from dataclasses import dataclass, field
from typing import Dict, List, Optional
from pathlib import Path


# ── TOPSIS criterion definitions ──────────────────────────────────────────────
TOPSIS_WEIGHTS: Dict[str, float] = {
    "accuracy":          0.25,
    "f1_score":          0.20,
    "train_time":        0.15,
    "memory_mb":         0.15,
    "num_params":        0.10,
    "energy_joules":     0.10,
    "model_size_kb":     0.05,
}

TOPSIS_IMPACTS: Dict[str, str] = {
    "accuracy":          "+",   # higher is better
    "f1_score":          "+",   # higher is better
    "train_time":        "-",   # lower is better
    "memory_mb":         "-",   # lower is better
    "num_params":        "-",   # lower is better
    "energy_joules":     "-",   # lower is better
    "model_size_kb":     "-",   # lower is better
}

# ── Search-space definition ───────────────────────────────────────────────────
SEARCH_SPACE: Dict = {
    "num_conv_layers": [2, 3, 4],
    "num_filters":     [16, 32, 64],
    "dropout_rate":    [0.0, 0.3, 0.5],
    "use_batchnorm":   [True, False],
    "activation":      ["relu", "leaky_relu", "elu"],
}

# ── Available datasets ────────────────────────────────────────────────────────
SUPPORTED_DATASETS = ["cifar10", "mnist", "uci_wine", "uci_breast_cancer"]

# ── Available search strategies ───────────────────────────────────────────────
SUPPORTED_STRATEGIES = ["random", "grid", "bayesian", "topsis_nas"]


@dataclass
class Config:
    # ── Datasets to evaluate ──────────────────────────────────────────────────
    datasets: List[str] = field(
        default_factory=lambda: ["cifar10", "mnist", "uci_wine", "uci_breast_cancer"]
    )

    # ── Search strategies to compare ─────────────────────────────────────────
    strategies: List[str] = field(
        default_factory=lambda: ["random", "grid", "bayesian", "topsis_nas"]
    )

    # ── Data ─────────────────────────────────────────────────────────────────
    data_dir: str      = "./data"
    batch_size: int    = 64
    num_workers: int   = 0          # 0 = main process (safer cross-platform)

    # ── Architecture search ───────────────────────────────────────────────────
    num_random_candidates: int  = 9    # random & topsis_nas (full grid = 9 configs)
    num_bayesian_trials:   int  = 9    # Bayesian iterations
    seed: int                   = 42

    # ── Training ─────────────────────────────────────────────────────────────
    epochs: int    = 3
    lr:     float  = 1e-3

    # ── TOPSIS ───────────────────────────────────────────────────────────────
    topsis_weights: Dict[str, float] = field(
        default_factory=lambda: dict(TOPSIS_WEIGHTS)
    )
    topsis_impacts: Dict[str, str] = field(
        default_factory=lambda: dict(TOPSIS_IMPACTS)
    )

    # ── Ablation study weight sets ────────────────────────────────────────────
    ablation_weight_sets: List[Dict[str, float]] = field(
        default_factory=lambda: [
            # Accuracy-only
            {"accuracy": 1.0, "f1_score": 0.0, "train_time": 0.0,
             "memory_mb": 0.0, "num_params": 0.0, "energy_joules": 0.0, "model_size_kb": 0.0},
            # Accuracy + F1
            {"accuracy": 0.5, "f1_score": 0.5, "train_time": 0.0,
             "memory_mb": 0.0, "num_params": 0.0, "energy_joules": 0.0, "model_size_kb": 0.0},
            # Speed-focused
            {"accuracy": 0.2, "f1_score": 0.1, "train_time": 0.4,
             "memory_mb": 0.2, "num_params": 0.1, "energy_joules": 0.0, "model_size_kb": 0.0},
            # Balanced (default)
            {"accuracy": 0.25, "f1_score": 0.20, "train_time": 0.15,
             "memory_mb": 0.15, "num_params": 0.10, "energy_joules": 0.10, "model_size_kb": 0.05},
            # Green-AI (energy-focused)
            {"accuracy": 0.20, "f1_score": 0.15, "train_time": 0.10,
             "memory_mb": 0.10, "num_params": 0.05, "energy_joules": 0.35, "model_size_kb": 0.05},
        ]
    )
    ablation_labels: List[str] = field(
        default_factory=lambda: [
            "Accuracy-Only",
            "Accuracy+F1",
            "Speed-Focused",
            "Balanced (Default)",
            "Green-AI",
        ]
    )

    # ── I/O ──────────────────────────────────────────────────────────────────
    output_dir: str = "./outputs"
    log_level:  str = "INFO"

    # ── Device (set in __post_init__) ─────────────────────────────────────────
    device: str = field(init=False)

    def __post_init__(self):
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        for d in [self.output_dir, self.data_dir]:
            Path(d).mkdir(parents=True, exist_ok=True)

        # Validate
        assert abs(sum(self.topsis_weights.values()) - 1.0) < 1e-5, \
            "topsis_weights must sum to 1.0"
        for ds in self.datasets:
            assert ds in SUPPORTED_DATASETS, f"Unknown dataset: {ds}"
        for st in self.strategies:
            assert st in SUPPORTED_STRATEGIES, f"Unknown strategy: {st}"
