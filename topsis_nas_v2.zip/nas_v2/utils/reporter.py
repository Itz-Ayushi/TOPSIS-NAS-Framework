"""
utils/reporter.py
-----------------
Handles all textual and CSV output for the full experiment matrix.

Outputs
~~~~~~~
  outputs/results_<dataset>_<strategy>.csv  – one CSV per (dataset, strategy)
  outputs/summary.csv                        – cross-experiment best-of table
  Console leaderboard                        – formatted per run
"""

import csv
import logging
from pathlib import Path
from typing import Dict, List, Any, Optional

log = logging.getLogger(__name__)

# Ordered columns for per-run CSV
_RUN_FIELDS = [
    "rank", "num_conv_layers", "num_filters", "activation",
    "use_batchnorm", "dropout_rate",
    "accuracy", "precision", "recall", "f1_score",
    "train_time", "memory_mb", "num_params", "model_size_kb",
    "energy_joules", "topsis_score",
]

# Columns for the summary CSV
_SUMMARY_FIELDS = [
    "dataset", "strategy",
    "best_accuracy", "best_f1", "best_topsis",
    "best_arch_layers", "best_arch_filters", "best_arch_activation",
]


class Reporter:
    """
    Writes leaderboards and CSVs for all experiment results.

    Args:
        output_dir: Directory for all output files.
    """

    def __init__(self, output_dir: str = "./outputs") -> None:
        self.out = Path(output_dir)
        self.out.mkdir(parents=True, exist_ok=True)

    # ── Per-run reporting ─────────────────────────────────────────────────────

    def print_leaderboard(
        self,
        ranked:   List[Dict[str, Any]],
        dataset:  str,
        strategy: str,
    ) -> None:
        """Print a compact ranked table to stdout."""
        header = (
            f"{'Rk':>2} {'Architecture':<28} "
            f"{'Acc':>6} {'F1':>6} {'T(s)':>6} "
            f"{'Mem':>5} {'Params':>8} {'TOPSIS':>7}"
        )
        sep = "-" * len(header)
        print(f"\n{sep}")
        print(f"  {dataset.upper()} × {strategy.upper()}")
        print(sep)
        print(header)
        print(sep)
        for r in ranked:
            a = r["arch"]
            arch_str = (
                f"Conv×{a.get('num_conv_layers')} "
                f"F{a.get('num_filters')} "
                f"{a.get('activation','?')[:4]} "
                f"BN={int(a.get('use_batchnorm',True))}"
            )
            print(
                f"{r['rank']:>2} {arch_str:<28} "
                f"{r.get('accuracy',0):>6.4f} "
                f"{r.get('f1_score',0):>6.4f} "
                f"{r.get('train_time',0):>6.1f} "
                f"{r.get('memory_mb',0):>5.1f} "
                f"{r.get('num_params',0):>8,} "
                f"{r.get('topsis_score',0):>7.4f}"
            )
        print(sep)

    def save_run_csv(
        self,
        ranked:   List[Dict[str, Any]],
        dataset:  str,
        strategy: str,
    ) -> str:
        """Save per-(dataset, strategy) results to CSV."""
        path = self.out / f"results_{dataset}_{strategy}.csv"
        with open(path, "w", newline="") as fh:
            writer = csv.DictWriter(fh, fieldnames=_RUN_FIELDS,
                                    extrasaction="ignore")
            writer.writeheader()
            for r in ranked:
                row = {
                    "rank":           r["rank"],
                    "num_conv_layers": r["arch"].get("num_conv_layers"),
                    "num_filters":    r["arch"].get("num_filters"),
                    "activation":     r["arch"].get("activation"),
                    "use_batchnorm":  r["arch"].get("use_batchnorm"),
                    "dropout_rate":   r["arch"].get("dropout_rate"),
                    **{k: round(r.get(k, 0), 6) for k in [
                        "accuracy", "precision", "recall", "f1_score",
                        "train_time", "memory_mb", "model_size_kb",
                        "energy_joules", "topsis_score",
                    ]},
                    "num_params": r.get("num_params", 0),
                }
                writer.writerow(row)
        log.info(f"  CSV saved → {path}")
        return str(path)

    # ── Summary reporting ─────────────────────────────────────────────────────

    def save_summary_csv(
        self,
        all_results: Dict[str, Dict[str, List[Dict[str, Any]]]],
    ) -> str:
        """
        Save a cross-experiment summary: one row per (dataset, strategy).
        """
        path = self.out / "summary.csv"
        rows = []
        for ds, strat_dict in all_results.items():
            for strategy, ranked in strat_dict.items():
                if not ranked:
                    continue
                best = ranked[0]
                rows.append({
                    "dataset":           ds,
                    "strategy":          strategy,
                    "best_accuracy":     round(best.get("accuracy",   0), 6),
                    "best_f1":           round(best.get("f1_score",   0), 6),
                    "best_topsis":       round(best.get("topsis_score",0), 6),
                    "best_arch_layers":  best["arch"].get("num_conv_layers"),
                    "best_arch_filters": best["arch"].get("num_filters"),
                    "best_arch_activation": best["arch"].get("activation"),
                })

        with open(path, "w", newline="") as fh:
            writer = csv.DictWriter(fh, fieldnames=_SUMMARY_FIELDS)
            writer.writeheader()
            writer.writerows(rows)

        log.info(f"  Summary CSV → {path}")
        return str(path)

    def print_final_summary(
        self,
        all_results: Dict[str, Dict[str, List[Dict[str, Any]]]],
    ) -> None:
        """Print a clean cross-experiment summary table."""
        print("\n" + "=" * 75)
        print("  FINAL EXPERIMENT SUMMARY")
        print("=" * 75)
        fmt = f"{'Dataset':<22} {'Strategy':<12} {'Accuracy':>8} {'F1':>7} {'TOPSIS':>8}  Best Architecture"
        print(fmt)
        print("-" * 75)
        for ds, strat_dict in all_results.items():
            for strategy, ranked in strat_dict.items():
                if not ranked:
                    continue
                b = ranked[0]
                a = b["arch"]
                arch_str = (
                    f"Conv×{a.get('num_conv_layers')} "
                    f"F{a.get('num_filters')} "
                    f"{a.get('activation')}"
                )
                print(
                    f"{ds:<22} {strategy:<12} "
                    f"{b.get('accuracy',0):>8.4f} "
                    f"{b.get('f1_score',0):>7.4f} "
                    f"{b.get('topsis_score',0):>8.4f}  "
                    f"{arch_str}"
                )
        print("=" * 75)
