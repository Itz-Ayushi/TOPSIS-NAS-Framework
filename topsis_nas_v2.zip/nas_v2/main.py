"""
main.py
=======
TOPSIS-Driven AutoML: Multi-Criteria Framework for Efficient NAS
================================================================

Full pipeline:
  1. Load all datasets (CIFAR-10, MNIST, UCI Wine, UCI Breast Cancer)
  2. Run all search strategies (Random, Grid, Bayesian, TOPSIS-NAS)
  3. Train every candidate architecture and collect 7 metrics
  4. Rank with TOPSIS (accuracy, F1, time, memory, params, energy, size)
  5. Run ablation study across 5 weight configurations
  6. Generate 7 visualisation plots + per-run CSVs + summary CSV

Usage:
    python main.py

Quickstart (fewer datasets/strategies for testing):
    Edit Config.datasets / Config.strategies / Config.epochs below.
"""

import logging
import sys
import os
from pathlib import Path

# ── Ensure project root is on PYTHONPATH ─────────────────────────────────────
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from utils.config  import Config
from utils.logger  import setup_logger
from utils.reporter import Reporter

from experiments.runner  import ExperimentRunner
from experiments.ablation import AblationStudy

from visualization.plots import (
    plot_performance_comparison,
    plot_metric_comparison,
    plot_pareto_front,
    plot_ranking_heatmap,
    plot_ablation_study,
    plot_radar_chart,
    plot_score_distribution,
)


def main() -> None:
    # ── Configuration ─────────────────────────────────────────────────────────
    cfg = Config()

    # ┌─────────────────────────────────────────────────────────────────────┐
    # │  Quick-tune knobs (edit here for faster / fuller experiments)       │
    # │                                                                     │
    # │  cfg.datasets   = ["cifar10"]          # single-dataset quick run  │
    # │  cfg.strategies = ["random","topsis_nas"]  # fewer strategies      │
    # │  cfg.epochs     = 2                    # fewer epochs              │
    # │  cfg.num_random_candidates = 4         # fewer candidates          │
    # └─────────────────────────────────────────────────────────────────────┘

    setup_logger(cfg.log_level)
    log = logging.getLogger(__name__)

    log.info("=" * 65)
    log.info("  TOPSIS-Driven AutoML — Comprehensive NAS Framework")
    log.info("=" * 65)
    log.info(f"  Device     : {cfg.device}")
    log.info(f"  Datasets   : {cfg.datasets}")
    log.info(f"  Strategies : {cfg.strategies}")
    log.info(f"  Epochs/run : {cfg.epochs}")
    log.info(f"  Candidates : {cfg.num_random_candidates}")
    log.info(f"  Output dir : {cfg.output_dir}")
    log.info("=" * 65)

    reporter = Reporter(output_dir=cfg.output_dir)

    # ── Phase 1: Run experiment matrix ────────────────────────────────────────
    log.info("\n▶ PHASE 1 — Running experiment matrix …")
    runner     = ExperimentRunner(cfg)
    all_results = runner.run()

    # ── Per-run reporting (leaderboard + CSV) ─────────────────────────────────
    for ds_name, strat_dict in all_results.items():
        for strategy, ranked in strat_dict.items():
            if not ranked:
                continue
            reporter.print_leaderboard(ranked, ds_name, strategy)
            reporter.save_run_csv(ranked, ds_name, strategy)

    # ── Phase 2: Ablation study ───────────────────────────────────────────────
    log.info("\n▶ PHASE 2 — Ablation study …")
    ablation  = AblationStudy(cfg)
    ablation_data = ablation.run(all_results)

    # ── Phase 3: Visualizations ───────────────────────────────────────────────
    log.info("\n▶ PHASE 3 — Generating visualizations …")

    saved_plots = []

    p = plot_performance_comparison(all_results, cfg.output_dir, metric="accuracy")
    if p: saved_plots.append(p)

    p = plot_metric_comparison(all_results, cfg.output_dir)
    if p: saved_plots.append(p)

    p = plot_pareto_front(all_results, cfg.output_dir,
                          x_metric="num_params", y_metric="accuracy")
    if p: saved_plots.append(p)

    p = plot_ranking_heatmap(all_results, cfg.output_dir)
    if p: saved_plots.append(p)

    p = plot_ablation_study(ablation_data, cfg.output_dir)
    if p: saved_plots.append(p)

    # Radar chart — use first dataset that has ≥2 strategies
    for ds in cfg.datasets:
        if len(all_results.get(ds, {})) >= 2:
            p = plot_radar_chart(all_results, cfg.output_dir, dataset=ds)
            if p:
                saved_plots.append(p)
            break

    p = plot_score_distribution(all_results, cfg.output_dir)
    if p: saved_plots.append(p)

    # ── Phase 4: Final summary ────────────────────────────────────────────────
    log.info("\n▶ PHASE 4 — Summary …")
    reporter.print_final_summary(all_results)
    reporter.save_summary_csv(all_results)

    # ── Done ──────────────────────────────────────────────────────────────────
    log.info("\n" + "=" * 65)
    log.info(f"  All outputs saved to: {cfg.output_dir}/")
    log.info(f"  Plots generated: {len(saved_plots)}")
    for p in saved_plots:
        log.info(f"    {Path(p).name}")
    log.info("=" * 65)
    log.info("  Run complete.")
    log.info("=" * 65)


if __name__ == "__main__":
    main()
