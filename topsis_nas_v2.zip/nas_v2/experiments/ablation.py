"""
experiments/ablation.py
-----------------------
Ablation study: re-ranks the SAME set of trained results using different
TOPSIS weight configurations.

This isolates the effect of criterion weighting on architecture selection
without re-training any models — making it fast and reproducible.

Weight sets are defined in Config.ablation_weight_sets.
"""

import logging
from typing import Dict, List, Any

import numpy as np

from topsis.ranker import TOPSISRanker, METRIC_KEYS
from utils.config import Config

log = logging.getLogger(__name__)

# Type: dataset → strategy → ranked results
ExperimentResults = Dict[str, Dict[str, List[Dict[str, Any]]]]


class AblationStudy:
    """
    Re-ranks pre-trained results under different weight configurations.

    Args:
        cfg: Master Config (contains ablation_weight_sets and impacts).
    """

    def __init__(self, cfg: Config) -> None:
        self.cfg = cfg

    def run(
        self,
        results: ExperimentResults,
    ) -> Dict[str, Any]:
        """
        Run the ablation study over all weight sets.

        For each (dataset, strategy) pair and each weight set:
        - Re-apply TOPSIS with the new weights
        - Record the best architecture and its score

        Returns:
            ablation_data dict structured as:
            {
              "labels":  [list of weight-set labels],
              "by_dataset_strategy": {
                  "cifar10/topsis_nas": {
                      "weight_set_0": {"best_arch": ..., "score": ...},
                      ...
                  },
                  ...
              },
              "score_matrix": {   # label → dataset/strategy → best TOPSIS score
                  "Accuracy-Only": {"cifar10/topsis_nas": 0.82, ...},
                  ...
              }
            }
        """
        labels          = self.cfg.ablation_labels
        weight_sets     = self.cfg.ablation_weight_sets

        by_ds_strategy: Dict[str, Dict[str, Any]] = {}
        score_matrix:   Dict[str, Dict[str, float]] = {lbl: {} for lbl in labels}

        for ds_name, strat_dict in results.items():
            for strategy, ranked in strat_dict.items():
                if not ranked:
                    continue

                key = f"{ds_name}/{strategy}"
                by_ds_strategy[key] = {}

                for label, w_set in zip(labels, weight_sets):
                    # Build ranker with this weight set
                    ranker = TOPSISRanker(
                        weights=w_set,
                        impacts=self.cfg.topsis_impacts,
                    )
                    re_ranked = ranker.rank(ranked)   # re-rank with new weights
                    best      = re_ranked[0]

                    by_ds_strategy[key][label] = {
                        "best_arch":    best["arch"],
                        "score":        best["topsis_score"],
                        "accuracy":     best["accuracy"],
                        "f1_score":     best["f1_score"],
                        "train_time":   best["train_time"],
                        "num_params":   best["num_params"],
                        "energy_joules":best["energy_joules"],
                    }
                    score_matrix[label][key] = best["topsis_score"]

                    log.debug(
                        f"  Ablation [{label}] {key}: "
                        f"score={best['topsis_score']:.4f}  "
                        f"acc={best['accuracy']:.4f}"
                    )

        log.info(f"Ablation study complete — {len(labels)} weight configurations evaluated.")
        return {
            "labels":                labels,
            "weight_sets":           weight_sets,
            "by_dataset_strategy":   by_ds_strategy,
            "score_matrix":          score_matrix,
        }
