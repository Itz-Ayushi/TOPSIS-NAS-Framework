"""
experiments/runner.py
---------------------
Runs the full NAS experiment matrix:
    for each dataset:
        for each search strategy:
            generate candidates → train → collect metrics → TOPSIS rank

Returns a nested dict:
    results[dataset_name][strategy_name] = List[ranked_result_dicts]

This module is intentionally side-effect-free (no CSV/plot writing);
all I/O is handled by the visualization and reporter modules.
"""

import logging
from typing import Dict, List, Any

from datasets.loader import load_dataset, DatasetBundle
from search import get_searcher
from metrics.collector import MetricsCollector
from topsis.ranker import TOPSISRanker
from utils.config import Config

log = logging.getLogger(__name__)

# Type alias for clarity
ExperimentResults = Dict[str, Dict[str, List[Dict[str, Any]]]]


class ExperimentRunner:
    """
    Coordinates the full experiment matrix.

    Args:
        cfg: Master Config object.
    """

    def __init__(self, cfg: Config) -> None:
        self.cfg    = cfg
        self.ranker = TOPSISRanker(
            weights=cfg.topsis_weights,
            impacts=cfg.topsis_impacts,
        )

    def run(self) -> ExperimentResults:
        """
        Execute all dataset × strategy combinations.

        Returns:
            Nested dict  results[dataset][strategy] = ranked list.
        """
        all_results: ExperimentResults = {}
        n_datasets   = len(self.cfg.datasets)
        n_strategies = len(self.cfg.strategies)
        total_runs   = n_datasets * n_strategies

        log.info(
            f"Experiment matrix: {n_datasets} datasets × "
            f"{n_strategies} strategies = {total_runs} runs"
        )

        run_idx = 0
        for ds_name in self.cfg.datasets:
            all_results[ds_name] = {}

            # Load dataset once — shared across all strategies
            log.info(f"\n{'='*60}")
            log.info(f"  DATASET: {ds_name.upper()}")
            log.info(f"{'='*60}")

            bundle = load_dataset(
                name=ds_name,
                data_dir=self.cfg.data_dir,
                batch_size=self.cfg.batch_size,
                num_workers=self.cfg.num_workers,
            )

            for strategy in self.cfg.strategies:
                run_idx += 1
                log.info(
                    f"\n[Run {run_idx}/{total_runs}]  "
                    f"Dataset={ds_name}  Strategy={strategy}"
                )

                try:
                    ranked = self._run_one(bundle, strategy)
                    all_results[ds_name][strategy] = ranked
                    log.info(
                        f"  ✓ Best: {self._arch_label(ranked[0]['arch'])}  "
                        f"TOPSIS={ranked[0]['topsis_score']:.4f}  "
                        f"acc={ranked[0]['accuracy']:.4f}"
                    )
                except Exception as exc:
                    log.error(
                        f"  ✗ Run failed ({ds_name}/{strategy}): {exc}",
                        exc_info=True,
                    )
                    all_results[ds_name][strategy] = []

        return all_results

    # ── Private ───────────────────────────────────────────────────────────────

    def _run_one(
        self,
        bundle:   DatasetBundle,
        strategy: str,
    ) -> List[Dict[str, Any]]:
        """Run one (dataset, strategy) combination end-to-end."""
        # Determine number of candidates for this strategy
        n = (
            self.cfg.num_bayesian_trials
            if strategy == "bayesian"
            else self.cfg.num_random_candidates
        )

        # 1. Generate candidate architectures
        searcher   = get_searcher(strategy, seed=self.cfg.seed)
        candidates = searcher.generate(n)
        log.info(f"  Generated {len(candidates)} candidates via {strategy}")

        # 2. Train & collect metrics
        collector = MetricsCollector(
            bundle=bundle,
            epochs=self.cfg.epochs,
            lr=self.cfg.lr,
            device=self.cfg.device,
        )
        raw_results = collector.evaluate_all(candidates)

        # 3. TOPSIS ranking
        ranked = self.ranker.rank(raw_results)
        return ranked

    @staticmethod
    def _arch_label(arch: Dict[str, Any]) -> str:
        return (
            f"Conv×{arch.get('num_conv_layers')} "
            f"F{arch.get('num_filters')} "
            f"{arch.get('activation')}"
        )
