"""
visualization/plots.py
----------------------
All matplotlib/seaborn visualizations for the NAS framework.

Plots generated
~~~~~~~~~~~~~~~
1. performance_comparison  – grouped bar: accuracy per strategy per dataset
2. metric_comparison       – multi-panel bars: all metrics × strategies
3. pareto_front            – accuracy vs num_params scatter with Pareto frontier
4. ranking_heatmap         – TOPSIS scores [dataset × strategy] heatmap
5. ablation_study          – bar chart of best scores under each weight config
6. radar_chart             – spider chart comparing best arch per strategy
7. convergence_curves      – rank stability across weight sets (ablation)

All functions accept pre-computed data dicts and return saved file paths.
The Agg backend is forced so the code works headlessly on any server.
"""

import logging
import math
from pathlib import Path
from typing import Dict, List, Any, Optional, Tuple

import numpy as np

log = logging.getLogger(__name__)

# ── Matplotlib setup (must happen before any other mpl import) ────────────────
try:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import matplotlib.patches as mpatches
    import matplotlib.gridspec as gridspec
    from matplotlib.lines import Line2D
    from matplotlib.patches import FancyArrowPatch
    _MPL_OK = True
except ImportError:
    _MPL_OK = False
    log.warning("matplotlib not available — skipping all plots.")

try:
    import seaborn as sns
    _SNS_OK = True
except ImportError:
    _SNS_OK = False


# ── Colour palette ────────────────────────────────────────────────────────────
STRATEGY_COLORS = {
    "random":     "#3498db",
    "grid":       "#e67e22",
    "bayesian":   "#9b59b6",
    "topsis_nas": "#2ecc71",
}
DATASET_MARKERS = {
    "cifar10":            "o",
    "mnist":              "s",
    "uci_wine":           "^",
    "uci_breast_cancer":  "D",
}
PALETTE = ["#2ecc71", "#3498db", "#9b59b6", "#e74c3c", "#f39c12",
           "#1abc9c", "#e67e22", "#34495e"]


def _save(fig, path: Path) -> str:
    path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    log.info(f"  Plot saved → {path}")
    return str(path)


# ─────────────────────────────────────────────────────────────────────────────
# 1. Performance comparison bar chart
# ─────────────────────────────────────────────────────────────────────────────

def plot_performance_comparison(
    results:    Dict[str, Dict[str, List[Dict[str, Any]]]],
    output_dir: str = "./outputs",
    metric:     str = "accuracy",
) -> Optional[str]:
    """
    Grouped bar chart: best <metric> per (dataset, strategy).

    Args:
        results:    results[dataset][strategy] = ranked list
        output_dir: Directory to save PNG.
        metric:     Which metric to plot on the Y-axis.

    Returns:
        File path of saved PNG, or None if matplotlib unavailable.
    """
    if not _MPL_OK:
        return None

    datasets   = list(results.keys())
    strategies = []
    for d in datasets:
        for s in results[d]:
            if s not in strategies:
                strategies.append(s)

    n_ds   = len(datasets)
    n_st   = len(strategies)
    x      = np.arange(n_ds)
    width  = 0.8 / n_st

    fig, ax = plt.subplots(figsize=(max(8, n_ds * 2), 5))

    for i, strategy in enumerate(strategies):
        scores = []
        for ds in datasets:
            ranked = results[ds].get(strategy, [])
            val    = ranked[0].get(metric, 0.0) if ranked else 0.0
            scores.append(val)

        bars = ax.bar(
            x + i * width - (n_st - 1) * width / 2,
            scores,
            width=width * 0.9,
            color=STRATEGY_COLORS.get(strategy, PALETTE[i % len(PALETTE)]),
            label=strategy,
            edgecolor="white",
            linewidth=0.5,
        )
        # Value labels on bars
        for bar, v in zip(bars, scores):
            if v > 0:
                ax.text(
                    bar.get_x() + bar.get_width() / 2,
                    bar.get_height() + 0.005,
                    f"{v:.3f}",
                    ha="center", va="bottom", fontsize=7, rotation=45,
                )

    ax.set_xticks(x)
    ax.set_xticklabels([d.replace("_", "\n") for d in datasets], fontsize=9)
    ax.set_ylabel(metric.replace("_", " ").title(), fontsize=11)
    ax.set_title(
        f"Best {metric.replace('_',' ').title()} per Strategy × Dataset",
        fontsize=13, fontweight="bold", pad=14,
    )
    ax.legend(fontsize=9, framealpha=0.7)
    ax.set_ylim(0, min(1.1, ax.get_ylim()[1] * 1.15))
    ax.spines[["top", "right"]].set_visible(False)
    ax.grid(axis="y", alpha=0.3, linestyle="--")

    return _save(fig, Path(output_dir) / "performance_comparison.png")


# ─────────────────────────────────────────────────────────────────────────────
# 2. Multi-metric comparison (all metrics side-by-side)
# ─────────────────────────────────────────────────────────────────────────────

def plot_metric_comparison(
    results:    Dict[str, Dict[str, List[Dict[str, Any]]]],
    output_dir: str = "./outputs",
) -> Optional[str]:
    """
    2-row grid of bar charts, one panel per metric.
    """
    if not _MPL_OK:
        return None

    metrics_to_plot = [
        ("accuracy",      "Accuracy",        True),
        ("f1_score",      "F1 Score",        True),
        ("precision",     "Precision",       True),
        ("recall",        "Recall",          True),
        ("train_time",    "Train Time (s)",  False),
        ("memory_mb",     "Memory (MB)",     False),
        ("num_params",    "Parameters",      False),
        ("energy_joules", "Energy (J)",      False),
    ]

    datasets   = list(results.keys())
    strategies = []
    for d in datasets:
        for s in results[d]:
            if s not in strategies:
                strategies.append(s)

    n_metrics = len(metrics_to_plot)
    n_cols    = 4
    n_rows    = math.ceil(n_metrics / n_cols)

    fig, axes = plt.subplots(n_rows, n_cols, figsize=(n_cols * 4, n_rows * 3.5))
    axes_flat = axes.flatten() if hasattr(axes, "flatten") else [axes]

    for ax_i, (mkey, mlabel, higher_better) in enumerate(metrics_to_plot):
        ax = axes_flat[ax_i]

        # Aggregate: mean over datasets per strategy
        strat_vals = {}
        for strategy in strategies:
            vals = []
            for ds in datasets:
                ranked = results[ds].get(strategy, [])
                if ranked:
                    vals.append(ranked[0].get(mkey, 0.0))
            strat_vals[strategy] = np.mean(vals) if vals else 0.0

        colors = [STRATEGY_COLORS.get(s, "#95a5a6") for s in strategies]
        bars   = ax.bar(strategies, [strat_vals[s] for s in strategies],
                        color=colors, edgecolor="white", linewidth=0.5)

        for bar in bars:
            h = bar.get_height()
            ax.text(bar.get_x() + bar.get_width() / 2, h * 1.01,
                    f"{h:.2f}", ha="center", va="bottom", fontsize=7)

        direction = "↑ better" if higher_better else "↓ better"
        ax.set_title(f"{mlabel}\n{direction}", fontsize=9, fontweight="bold")
        ax.set_xticklabels(strategies, rotation=30, ha="right", fontsize=7)
        ax.spines[["top", "right"]].set_visible(False)
        ax.grid(axis="y", alpha=0.3, linestyle="--")

    # Hide unused axes
    for ax_i in range(len(metrics_to_plot), len(axes_flat)):
        axes_flat[ax_i].set_visible(False)

    fig.suptitle(
        "Multi-Metric Comparison Across Search Strategies\n(mean over datasets)",
        fontsize=12, fontweight="bold", y=1.01,
    )
    plt.tight_layout()
    return _save(fig, Path(output_dir) / "metric_comparison.png")


# ─────────────────────────────────────────────────────────────────────────────
# 3. Pareto Front — accuracy vs complexity
# ─────────────────────────────────────────────────────────────────────────────

def plot_pareto_front(
    results:    Dict[str, Dict[str, List[Dict[str, Any]]]],
    output_dir: str = "./outputs",
    x_metric:   str = "num_params",
    y_metric:   str = "accuracy",
) -> Optional[str]:
    """
    Scatter of all evaluated architectures; Pareto-optimal ones are highlighted.

    X-axis: model complexity (num_params)
    Y-axis: accuracy
    Color:  search strategy
    Shape:  dataset
    Size:   TOPSIS score
    """
    if not _MPL_OK:
        return None

    fig, ax = plt.subplots(figsize=(10, 6))

    all_points: List[Dict] = []

    for ds_name, strat_dict in results.items():
        for strategy, ranked in strat_dict.items():
            for r in ranked:
                all_points.append({
                    "x":        r.get(x_metric, 0),
                    "y":        r.get(y_metric, 0),
                    "topsis":   r.get("topsis_score", 0.5),
                    "strategy": strategy,
                    "dataset":  ds_name,
                    "arch":     r.get("arch", {}),
                })

    if not all_points:
        plt.close(fig)
        return None

    # Compute Pareto front (minimise x, maximise y)
    pareto_indices = _pareto_front(
        [(p["x"], p["y"]) for p in all_points]
    )

    # Plot all points
    for idx, pt in enumerate(all_points):
        color  = STRATEGY_COLORS.get(pt["strategy"], "#95a5a6")
        marker = DATASET_MARKERS.get(pt["dataset"], "o")
        size   = 60 + pt["topsis"] * 200

        ax.scatter(
            pt["x"], pt["y"],
            c=color, marker=marker, s=size,
            alpha=0.6, edgecolors="white", linewidths=0.5, zorder=2,
        )

    # Highlight Pareto-optimal points
    pareto_pts = sorted([all_points[i] for i in pareto_indices],
                        key=lambda p: p["x"])
    px = [p["x"] for p in pareto_pts]
    py = [p["y"] for p in pareto_pts]

    ax.plot(px, py, "k--", linewidth=1.5, alpha=0.6, zorder=3, label="Pareto front")
    ax.scatter(px, py, c="black", s=120, zorder=4, marker="*",
               label="Pareto-optimal")

    # Legends
    strategy_handles = [
        mpatches.Patch(color=STRATEGY_COLORS.get(s, "#95a5a6"), label=s)
        for s in set(p["strategy"] for p in all_points)
    ]
    dataset_handles = [
        Line2D([0], [0], marker=DATASET_MARKERS.get(d, "o"),
               color="gray", linestyle="", markersize=8, label=d)
        for d in set(p["dataset"] for p in all_points)
    ]

    leg1 = ax.legend(handles=strategy_handles, loc="lower right",
                     fontsize=8, title="Strategy", title_fontsize=8)
    ax.add_artist(leg1)
    ax.legend(handles=dataset_handles + [
        Line2D([0], [0], linestyle="--", color="black", label="Pareto front"),
        Line2D([0], [0], marker="*", color="black", linestyle="", markersize=10,
               label="Pareto-optimal"),
    ], loc="lower left", fontsize=8, title="Dataset", title_fontsize=8)

    ax.set_xlabel(x_metric.replace("_", " ").title(), fontsize=11)
    ax.set_ylabel(y_metric.replace("_", " ").title(), fontsize=11)
    ax.set_title(
        f"Pareto Front: {y_metric.replace('_',' ').title()} vs "
        f"{x_metric.replace('_',' ').title()}\n"
        f"(dot size ∝ TOPSIS score)",
        fontsize=12, fontweight="bold",
    )
    ax.spines[["top", "right"]].set_visible(False)
    ax.grid(alpha=0.25, linestyle="--")
    ax.xaxis.set_major_formatter(
        matplotlib.ticker.FuncFormatter(lambda x, _: f"{x/1000:.0f}k")
    )

    return _save(fig, Path(output_dir) / "pareto_front.png")


def _pareto_front(points: List[Tuple[float, float]]) -> List[int]:
    """
    Return indices of Pareto-optimal points (minimise x, maximise y).
    A point is Pareto-optimal if no other point is at least as good on
    all dimensions and strictly better on one.
    """
    pareto = []
    for i, (xi, yi) in enumerate(points):
        dominated = False
        for j, (xj, yj) in enumerate(points):
            if i == j:
                continue
            if xj <= xi and yj >= yi and (xj < xi or yj > yi):
                dominated = True
                break
        if not dominated:
            pareto.append(i)
    return pareto


# ─────────────────────────────────────────────────────────────────────────────
# 4. Ranking heatmap
# ─────────────────────────────────────────────────────────────────────────────

def plot_ranking_heatmap(
    results:    Dict[str, Dict[str, List[Dict[str, Any]]]],
    output_dir: str = "./outputs",
) -> Optional[str]:
    """
    Heatmap of TOPSIS scores: rows = datasets, columns = strategies.
    Cell colour = best TOPSIS score achieved in that (dataset, strategy) cell.
    """
    if not _MPL_OK:
        return None

    datasets   = list(results.keys())
    strategies = []
    for d in datasets:
        for s in results[d]:
            if s not in strategies:
                strategies.append(s)

    matrix = np.zeros((len(datasets), len(strategies)))
    for i, ds in enumerate(datasets):
        for j, st in enumerate(strategies):
            ranked = results[ds].get(st, [])
            matrix[i, j] = ranked[0]["topsis_score"] if ranked else np.nan

    fig, ax = plt.subplots(figsize=(max(6, len(strategies) * 1.8),
                                    max(4, len(datasets) * 1.2)))

    if _SNS_OK:
        sns.heatmap(
            matrix,
            annot=True, fmt=".4f", cmap="YlGn",
            xticklabels=strategies,
            yticklabels=[d.replace("_", "\n") for d in datasets],
            ax=ax, linewidths=0.5, linecolor="white",
            cbar_kws={"label": "TOPSIS Score"},
            vmin=0, vmax=1,
        )
    else:
        im = ax.imshow(matrix, cmap="YlGn", vmin=0, vmax=1, aspect="auto")
        plt.colorbar(im, ax=ax, label="TOPSIS Score")
        ax.set_xticks(range(len(strategies)))
        ax.set_xticklabels(strategies, rotation=30, ha="right")
        ax.set_yticks(range(len(datasets)))
        ax.set_yticklabels([d.replace("_", "\n") for d in datasets])
        for i in range(len(datasets)):
            for j in range(len(strategies)):
                v = matrix[i, j]
                ax.text(j, i, f"{v:.3f}", ha="center", va="center",
                        fontsize=9, color="black" if v < 0.7 else "white")

    ax.set_title(
        "TOPSIS Score Heatmap\n(Best Architecture per Dataset × Strategy)",
        fontsize=12, fontweight="bold", pad=14,
    )
    ax.set_xlabel("Search Strategy", fontsize=10)
    ax.set_ylabel("Dataset",          fontsize=10)

    plt.tight_layout()
    return _save(fig, Path(output_dir) / "ranking_heatmap.png")


# ─────────────────────────────────────────────────────────────────────────────
# 5. Ablation study bar chart
# ─────────────────────────────────────────────────────────────────────────────

def plot_ablation_study(
    ablation_data: Dict[str, Any],
    output_dir:    str = "./outputs",
) -> Optional[str]:
    """
    Bar chart showing how the best TOPSIS score changes under each
    ablation weight configuration, per (dataset, strategy) pair.
    """
    if not _MPL_OK:
        return None

    labels        = ablation_data["labels"]
    by_ds_strat   = ablation_data["by_dataset_strategy"]
    score_matrix  = ablation_data["score_matrix"]   # label → key → score

    keys    = list(by_ds_strat.keys())
    n_keys  = len(keys)
    n_lbls  = len(labels)

    if n_keys == 0:
        return None

    x      = np.arange(n_lbls)
    width  = 0.8 / n_keys

    fig, ax = plt.subplots(figsize=(max(10, n_lbls * 2), 5))

    for i, key in enumerate(keys):
        scores = [score_matrix[lbl].get(key, 0.0) for lbl in labels]
        offset = (i - (n_keys - 1) / 2) * width
        color  = PALETTE[i % len(PALETTE)]
        bars   = ax.bar(x + offset, scores, width=width * 0.9,
                        color=color, label=key.replace("/", "\n"),
                        edgecolor="white", linewidth=0.4)
        for bar, v in zip(bars, scores):
            if v > 0:
                ax.text(bar.get_x() + bar.get_width() / 2,
                        bar.get_height() + 0.003,
                        f"{v:.3f}", ha="center", va="bottom",
                        fontsize=6.5, rotation=60)

    ax.set_xticks(x)
    ax.set_xticklabels(labels, rotation=20, ha="right", fontsize=9)
    ax.set_ylabel("Best TOPSIS Score", fontsize=11)
    ax.set_title(
        "Ablation Study: Effect of Criterion Weights on TOPSIS Score",
        fontsize=12, fontweight="bold", pad=12,
    )
    ax.legend(fontsize=7, ncol=max(1, n_keys // 3), loc="upper right",
              framealpha=0.7)
    ax.set_ylim(0, 1.1)
    ax.spines[["top", "right"]].set_visible(False)
    ax.grid(axis="y", alpha=0.3, linestyle="--")

    plt.tight_layout()
    return _save(fig, Path(output_dir) / "ablation_study.png")


# ─────────────────────────────────────────────────────────────────────────────
# 6. Radar chart — best architecture per strategy
# ─────────────────────────────────────────────────────────────────────────────

def plot_radar_chart(
    results:    Dict[str, Dict[str, List[Dict[str, Any]]]],
    output_dir: str = "./outputs",
    dataset:    str = "cifar10",
) -> Optional[str]:
    """
    Spider/radar chart comparing all strategies on the same dataset.
    Each spoke = one normalised metric; each polygon = one strategy.
    """
    if not _MPL_OK:
        return None

    spoke_metrics = [
        ("accuracy",       True),
        ("f1_score",       True),
        ("precision",      True),
        ("recall",         True),
        ("train_time",     False),
        ("memory_mb",      False),
        ("num_params",     False),
        ("energy_joules",  False),
    ]
    labels_spoke = [m for m, _ in spoke_metrics]
    n_spokes     = len(labels_spoke)

    # Collect best-arch metrics per strategy for the chosen dataset
    strategy_data: Dict[str, List[float]] = {}
    strat_dict = results.get(dataset, {})
    for strategy, ranked in strat_dict.items():
        if not ranked:
            continue
        r = ranked[0]
        strategy_data[strategy] = [r.get(m, 0.0) for m, _ in spoke_metrics]

    if len(strategy_data) < 2:
        log.warning(f"Not enough strategies for radar chart on {dataset}")
        return None

    # Normalise each spoke: benefit → value/max, cost → min/value
    col_vals = np.array(list(strategy_data.values()))  # [n_strat × n_spokes]
    normed   = np.zeros_like(col_vals)
    for j, (_, higher_better) in enumerate(spoke_metrics):
        col = col_vals[:, j]
        cmin, cmax = col.min(), col.max()
        rng = cmax - cmin if cmax != cmin else 1.0
        if higher_better:
            normed[:, j] = (col - cmin) / rng
        else:
            normed[:, j] = (cmax - col) / rng   # invert: lower original → higher normalised

    # Angles
    angles = np.linspace(0, 2 * np.pi, n_spokes, endpoint=False).tolist()
    angles += angles[:1]  # close polygon

    fig, ax = plt.subplots(figsize=(7, 7), subplot_kw={"polar": True})

    for i, (strategy, _) in enumerate(strategy_data.items()):
        vals = list(normed[i]) + [normed[i][0]]
        color = STRATEGY_COLORS.get(strategy, PALETTE[i % len(PALETTE)])
        ax.plot(angles, vals, color=color, linewidth=2, label=strategy)
        ax.fill(angles, vals, color=color, alpha=0.15)

    ax.set_xticks(angles[:-1])
    ax.set_xticklabels(
        [l.replace("_", "\n") for l in labels_spoke], fontsize=8
    )
    ax.set_ylim(0, 1)
    ax.set_yticks([0.25, 0.5, 0.75, 1.0])
    ax.set_yticklabels(["0.25", "0.50", "0.75", "1.00"], fontsize=7)
    ax.grid(True, alpha=0.3)

    ax.set_title(
        f"Radar Chart — Best Architecture per Strategy\n({dataset})",
        fontsize=12, fontweight="bold", pad=20,
    )
    ax.legend(loc="upper right", bbox_to_anchor=(1.35, 1.1), fontsize=9)

    return _save(fig, Path(output_dir) / f"radar_{dataset}.png")


# ─────────────────────────────────────────────────────────────────────────────
# 7. TOPSIS score distribution (box plots)
# ─────────────────────────────────────────────────────────────────────────────

def plot_score_distribution(
    results:    Dict[str, Dict[str, List[Dict[str, Any]]]],
    output_dir: str = "./outputs",
) -> Optional[str]:
    """
    Box plot of TOPSIS score distributions per strategy across datasets.
    Shows spread and median — useful for robustness analysis.
    """
    if not _MPL_OK:
        return None

    strategies = []
    for d in results:
        for s in results[d]:
            if s not in strategies:
                strategies.append(s)

    # Collect all TOPSIS scores per strategy (across all datasets + all archs)
    data_per_strategy: Dict[str, List[float]] = {s: [] for s in strategies}
    for ds, strat_dict in results.items():
        for strategy, ranked in strat_dict.items():
            for r in ranked:
                data_per_strategy[strategy].append(r.get("topsis_score", 0.0))

    fig, ax = plt.subplots(figsize=(max(6, len(strategies) * 1.5), 5))

    bp_data   = [data_per_strategy[s] for s in strategies]
    bp_colors = [STRATEGY_COLORS.get(s, "#95a5a6") for s in strategies]

    bp = ax.boxplot(
        bp_data, patch_artist=True, notch=False,
        medianprops={"color": "black", "linewidth": 2},
        whiskerprops={"linestyle": "--"},
    )
    for patch, color in zip(bp["boxes"], bp_colors):
        patch.set_facecolor(color)
        patch.set_alpha(0.7)

    ax.set_xticklabels(strategies, fontsize=10)
    ax.set_ylabel("TOPSIS Score", fontsize=11)
    ax.set_title(
        "TOPSIS Score Distribution per Search Strategy\n(all datasets & candidates)",
        fontsize=12, fontweight="bold",
    )
    ax.set_ylim(0, 1.05)
    ax.spines[["top", "right"]].set_visible(False)
    ax.grid(axis="y", alpha=0.3, linestyle="--")

    plt.tight_layout()
    return _save(fig, Path(output_dir) / "score_distribution.png")
