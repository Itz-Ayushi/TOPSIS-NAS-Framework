"""
search/random_search.py
-----------------------
Random search: samples architecture configurations uniformly at random
from the discrete search space, without replacement.
"""

import random
from typing import List, Dict, Any

from search.base import BaseSearcher
from utils.config import SEARCH_SPACE


class RandomSearcher(BaseSearcher):
    """
    Uniform random sampling over the discrete search space.

    Args:
        seed: RNG seed for reproducibility.
    """

    def __init__(self, seed: int = 42) -> None:
        self._rng = random.Random(seed)

    @property
    def name(self) -> str:
        return "random"

    def generate(self, n: int) -> List[Dict[str, Any]]:
        """
        Sample *n* unique architecture configurations.

        Raises:
            ValueError: If n > |search space|.
        """
        all_configs = self._full_grid()
        max_n = len(all_configs)
        if n > max_n:
            raise ValueError(
                f"Requested {n} configs but search space has only {max_n}."
            )
        return self._rng.sample(all_configs, k=n)

    @staticmethod
    def _full_grid() -> List[Dict[str, Any]]:
        """Enumerate every point in the Cartesian product of SEARCH_SPACE."""
        from itertools import product
        keys   = list(SEARCH_SPACE.keys())
        values = [SEARCH_SPACE[k] for k in keys]
        return [dict(zip(keys, combo)) for combo in product(*values)]

    @property
    def search_space_size(self) -> int:
        size = 1
        for v in SEARCH_SPACE.values():
            size *= len(v)
        return size
