"""
search/grid_search.py
---------------------
Grid search: enumerates every configuration in the search space
in a deterministic order.  When n < |grid| the first n configs
after shuffling by a fixed seed are returned so the subset is
reproducible but not always the same corner of the grid.
"""

from typing import List, Dict, Any

from search.random_search import RandomSearcher   # reuse _full_grid
from search.base import BaseSearcher


class GridSearcher(BaseSearcher):
    """
    Systematic enumeration of the full Cartesian product of SEARCH_SPACE.

    Args:
        seed: Seed used only for sub-sampling when n < grid size.
    """

    def __init__(self, seed: int = 42) -> None:
        self._seed = seed

    @property
    def name(self) -> str:
        return "grid"

    def generate(self, n: int) -> List[Dict[str, Any]]:
        """Return first *n* configurations from the sorted grid."""
        grid = RandomSearcher._full_grid()
        # Deterministic ordering: sort by string repr
        grid.sort(key=lambda d: str(sorted(d.items())))
        return grid[:n]
