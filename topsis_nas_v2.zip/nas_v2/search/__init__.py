from .random_search   import RandomSearcher
from .grid_search     import GridSearcher
from .bayesian_search import BayesianSearcher
from .topsis_nas      import TOPSISNASSearcher

__all__ = [
    "RandomSearcher", "GridSearcher",
    "BayesianSearcher", "TOPSISNASSearcher",
]

def get_searcher(name: str, seed: int = 42):
    """Factory: return the correct searcher by strategy name."""
    mapping = {
        "random":     RandomSearcher(seed=seed),
        "grid":       GridSearcher(seed=seed),
        "bayesian":   BayesianSearcher(seed=seed),
        "topsis_nas": TOPSISNASSearcher(seed=seed),
    }
    if name not in mapping:
        raise ValueError(f"Unknown strategy '{name}'. Options: {list(mapping)}")
    return mapping[name]
