"""
search/base.py
--------------
Abstract base class that all search strategies must implement.
"""

from abc import ABC, abstractmethod
from typing import List, Dict, Any


class BaseSearcher(ABC):
    """
    Interface for architecture search strategies.

    Every strategy must implement generate(), which returns a list
    of architecture dicts ready to be passed to MetricsCollector.
    """

    @abstractmethod
    def generate(self, n: int) -> List[Dict[str, Any]]:
        """
        Produce *n* architecture configurations.

        Args:
            n: Number of configurations to generate.

        Returns:
            List of arch dicts, e.g.:
            [{"num_conv_layers": 3, "num_filters": 32,
              "dropout_rate": 0.3, "use_batchnorm": True,
              "activation": "relu"}, ...]
        """

    @property
    def name(self) -> str:
        return self.__class__.__name__
