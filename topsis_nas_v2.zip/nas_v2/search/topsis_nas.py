"""
search/topsis_nas.py
--------------------
TOPSIS-NAS: our proposed method.

Strategy
~~~~~~~~
1. Enumerate the full search space (or sample a large random subset).
2. Compute a *lightweight proxy score* for every config using only
   structural properties (no training required at this stage):
       - parameter count (from FlexibleCNN.count_parameters())
       - estimated FLOPs (based on layer depth and filter count)
       - architectural diversity score
3. Run TOPSIS on these proxy metrics to pre-rank all configs.
4. Return the top-n configs from the TOPSIS pre-ranking for
   full evaluation by MetricsCollector.

This mimics the "once-for-all" NAS paradigm: we use TOPSIS as the
selection criterion even during the search phase, not just at the end.
The final TOPSIS ranking (post-training) is then applied on top of
the trained metrics.
"""

import logging
from typing import List, Dict, Any, Tuple

import numpy as np

from search.base import BaseSearcher
from search.random_search import RandomSearcher
from models.flexible_cnn import FlexibleCNN
from utils.config import SEARCH_SPACE

log = logging.getLogger(__name__)

# Dummy input shape for parameter counting — CIFAR-like default
_PROXY_INPUT  = (3, 32, 32)
_PROXY_CLS    = 10


def _proxy_metrics(cfg: Dict[str, Any]) -> Dict[str, float]:
    """
    Estimate structural metrics without any training.
    Returns a dict with proxy_params, proxy_flops, proxy_diversity.
    """
    # Parameter count from a dummy instantiation
    try:
        m = FlexibleCNN(cfg, _PROXY_INPUT, _PROXY_CLS, "image")
        params = float(m.count_parameters())
    except Exception:
        params = float("inf")

    # Rough FLOPs proxy: conv layers × filters² (very simplified)
    nl = cfg.get("num_conv_layers", 3)
    nf = cfg.get("num_filters", 32)
    flops = float(nl * nf * nf * 32 * 32)   # relative, not absolute

    # Diversity bonus: BN + non-ReLU activations add representational power
    diversity = (
        (1.0 if cfg.get("use_batchnorm") else 0.5)
        + {"relu": 0.3, "leaky_relu": 0.6, "elu": 0.9}.get(cfg.get("activation","relu"), 0.3)
        + (1.0 - cfg.get("dropout_rate", 0.3))
    )

    return {
        "proxy_params":    params,
        "proxy_flops":     flops,
        "proxy_diversity": diversity,
    }


def _topsis_prerank(
    configs:  List[Dict[str, Any]],
    weights:  Tuple[float, ...] = (0.4, 0.3, 0.3),
    impacts:  Tuple[str, ...]   = ("-", "-", "+"),
) -> List[int]:
    """
    Apply TOPSIS on proxy metrics and return sorted indices (best first).
    """
    keys = ["proxy_params", "proxy_flops", "proxy_diversity"]
    X = np.array([[_proxy_metrics(c)[k] for k in keys] for c in configs],
                 dtype=np.float64)

    # Vector normalise (guard against zero-norm columns)
    norms = np.sqrt((X ** 2).sum(0))
    norms = np.where(norms == 0, 1e-12, norms)
    R = X / norms
    W = np.array(weights)
    V = R * W

    # Ideal / anti-ideal
    A_pos = np.where(np.array(impacts) == "+", V.max(0), V.min(0))
    A_neg = np.where(np.array(impacts) == "+", V.min(0), V.max(0))

    d_pos = np.sqrt(((V - A_pos) ** 2).sum(1))
    d_neg = np.sqrt(((V - A_neg) ** 2).sum(1))
    denom = d_pos + d_neg
    denom[denom == 0] = 1e-12
    scores = d_neg / denom

    return list(np.argsort(-scores))   # descending


class TOPSISNASSearcher(BaseSearcher):
    """
    TOPSIS-guided NAS: pre-ranks all candidates using structural proxies,
    then selects the top-n for full evaluation.

    Args:
        seed: RNG seed for the initial random pool.
    """

    def __init__(self, seed: int = 42) -> None:
        self._seed = seed

    @property
    def name(self) -> str:
        return "topsis_nas"

    def generate(self, n: int) -> List[Dict[str, Any]]:
        """
        Return top *n* configs after TOPSIS pre-ranking of the full grid.
        """
        full_grid = RandomSearcher._full_grid()
        log.debug(f"TOPSIS-NAS: pre-ranking {len(full_grid)} configs …")

        ranked_idx = _topsis_prerank(full_grid)
        top_n      = [full_grid[i] for i in ranked_idx[:n]]

        log.debug(f"TOPSIS-NAS: selected {len(top_n)} configs for full evaluation.")
        return top_n
