"""
search/bayesian_search.py
-------------------------
Bayesian Optimisation (BO) over the discrete NAS search space.

Implementation
~~~~~~~~~~~~~~
We use a Gaussian Process (GP) surrogate with Upper Confidence Bound
(UCB) acquisition function.  Because the search space is discrete, we:

1. Encode each dimension numerically.
2. Fit a GP on the evaluated (config → score) pairs.
3. Select the next config by maximising UCB over the unevaluated grid.
4. Use a *proxy score* (weighted sum of normalised metrics) to provide
   the acquisition signal without running the full trainer — the trainer
   is run only on the selected config, matching real BO practice.

For the first `n_initial` trials random configs are used (warm-start).
Subsequent trials are guided by the GP surrogate.

Dependencies: scikit-learn (GaussianProcessRegressor).
"""

import logging
import random
from typing import List, Dict, Any, Optional

import numpy as np
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import Matern
from sklearn.preprocessing import LabelEncoder

from search.base import BaseSearcher
from search.random_search import RandomSearcher
from utils.config import SEARCH_SPACE

log = logging.getLogger(__name__)


# ── Encoding helpers ──────────────────────────────────────────────────────────

_KEYS   = list(SEARCH_SPACE.keys())
_ENCODERS: Dict[str, LabelEncoder] = {}

def _encode_config(cfg: Dict[str, Any]) -> np.ndarray:
    """Map a config dict to a 1-D float vector."""
    global _ENCODERS
    row = []
    for k in _KEYS:
        if k not in _ENCODERS:
            enc = LabelEncoder()
            enc.fit(SEARCH_SPACE[k])
            _ENCODERS[k] = enc
        row.append(float(_ENCODERS[k].transform([cfg[k]])[0]))
    return np.array(row)

def _encode_grid(grid: List[Dict[str, Any]]) -> np.ndarray:
    return np.vstack([_encode_config(c) for c in grid])


# ── Proxy score (used only by GP surrogate during BO) ────────────────────────

def _proxy_score(cfg: Dict[str, Any]) -> float:
    """
    Cheap heuristic score for warm-start without full training.
    Higher = expected to be better under a balanced criterion.
    Used only for seeding the GP; actual metrics come from the trainer.
    """
    nl_score  = 1.0 / cfg["num_conv_layers"]          # fewer layers → faster
    nf_score  = 1.0 / cfg["num_filters"]               # fewer filters → smaller
    dr_score  = 1.0 - cfg["dropout_rate"]              # less dropout → faster
    bn_score  = 0.1 if cfg["use_batchnorm"] else 0.0   # BN slightly preferred
    act_score = {"relu": 0.2, "leaky_relu": 0.15, "elu": 0.1}.get(
        cfg["activation"], 0.1
    )
    return nl_score + nf_score + dr_score + bn_score + act_score


class BayesianSearcher(BaseSearcher):
    """
    Bayesian Optimisation searcher using a GP surrogate + UCB acquisition.

    Args:
        n_initial: Number of random warm-start trials before BO begins.
        kappa:     UCB exploration factor (higher → more exploration).
        seed:      RNG seed.
    """

    def __init__(
        self,
        n_initial: int   = 3,
        kappa:     float = 2.0,
        seed:      int   = 42,
    ) -> None:
        self.n_initial = n_initial
        self.kappa     = kappa
        self._rng      = random.Random(seed)
        self._np_rng   = np.random.default_rng(seed)

    @property
    def name(self) -> str:
        return "bayesian"

    def generate(self, n: int) -> List[Dict[str, Any]]:
        """
        Return *n* architecture configurations chosen via BO.

        The first `n_initial` are random; subsequent picks are
        GP-UCB guided from the remaining unevaluated grid.
        """
        full_grid = RandomSearcher._full_grid()
        self._rng.shuffle(full_grid)

        selected:   List[Dict[str, Any]] = []
        observed_X: List[np.ndarray]     = []
        observed_y: List[float]          = []
        remaining                        = list(full_grid)

        # ── Warm-start: random initial trials ─────────────────────────────────
        n_init = min(self.n_initial, n, len(remaining))
        for _ in range(n_init):
            cfg = remaining.pop(0)
            selected.append(cfg)
            observed_X.append(_encode_config(cfg))
            observed_y.append(_proxy_score(cfg))

        if len(selected) >= n:
            return selected[:n]

        # ── GP surrogate with UCB acquisition ─────────────────────────────────
        kernel = Matern(nu=2.5)
        gp     = GaussianProcessRegressor(
            kernel=kernel, alpha=1e-6,
            normalize_y=True, random_state=0,
        )

        while len(selected) < n and remaining:
            X_obs = np.vstack(observed_X)
            y_obs = np.array(observed_y)
            gp.fit(X_obs, y_obs)

            X_rem  = _encode_grid(remaining)
            mu, sigma = gp.predict(X_rem, return_std=True)
            ucb    = mu + self.kappa * sigma         # UCB acquisition
            best_i = int(np.argmax(ucb))

            chosen = remaining.pop(best_i)
            selected.append(chosen)
            observed_X.append(_encode_config(chosen))
            observed_y.append(_proxy_score(chosen))

            log.debug(
                f"  BO selected: {chosen}  "
                f"UCB={ucb[best_i]:.4f}"
            )

        return selected[:n]
