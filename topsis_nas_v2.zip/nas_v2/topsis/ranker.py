"""
topsis/ranker.py
----------------
Pure NumPy TOPSIS implementation supporting all 7 evaluation metrics.

Algorithm (Hwang & Yoon, 1981)
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
1. Build decision matrix  X  [n × m]
2. Vector-normalise:       R = X / ‖X‖_col
3. Weight:                 V = W ⊙ R
4. Ideal A+  (best per criterion direction)
   Anti-ideal A-
5. Euclidean distances  d+, d-
6. Closeness score  C = d- / (d+ + d-)
7. Rank by descending C

All metric keys, weights, and impacts are injected at construction
time so the ranker is fully generic — no hard-coded metric names.
"""

import logging
from typing import List, Dict, Any

import numpy as np

log = logging.getLogger(__name__)

# Canonical metric order (defines matrix column order)
METRIC_KEYS = [
    "accuracy",
    "f1_score",
    "train_time",
    "memory_mb",
    "num_params",
    "energy_joules",
    "model_size_kb",
]


class TOPSISRanker:
    """
    Ranks evaluated architectures using TOPSIS.

    Args:
        weights: Dict mapping metric name → weight (must sum to 1.0).
        impacts: Dict mapping metric name → '+' (benefit) or '-' (cost).
    """

    def __init__(
        self,
        weights: Dict[str, float],
        impacts: Dict[str, str],
    ) -> None:
        self._validate(weights, impacts)
        self.weights = weights
        self.impacts = impacts

    # ── Public API ────────────────────────────────────────────────────────────

    def rank(self, results: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Apply TOPSIS and return results sorted by descending TOPSIS score.

        Each result dict gets two new keys:
            topsis_score (float)  – closeness coefficient C_i ∈ [0, 1]
            rank         (int)    – 1-indexed rank (1 = best)
        """
        if len(results) < 2:
            # Single candidate: trivially rank 1
            r = dict(results[0])
            r["topsis_score"] = 1.0
            r["rank"]         = 1
            return [r]

        X = self._build_matrix(results)             # [n × m]

        # ── Steps 2-3: normalise and weight ───────────────────────────────────
        norms = np.sqrt((X ** 2).sum(axis=0))
        norms[norms == 0] = 1e-12
        V = (X / norms) * np.array([self.weights[k] for k in METRIC_KEYS])

        # ── Step 4: ideal / anti-ideal ────────────────────────────────────────
        A_pos = np.zeros(len(METRIC_KEYS))
        A_neg = np.zeros(len(METRIC_KEYS))
        for j, key in enumerate(METRIC_KEYS):
            col = V[:, j]
            if self.impacts[key] == "+":
                A_pos[j], A_neg[j] = col.max(), col.min()
            else:
                A_pos[j], A_neg[j] = col.min(), col.max()

        # ── Steps 5-6: distances and closeness ───────────────────────────────
        d_pos = np.sqrt(((V - A_pos) ** 2).sum(axis=1))
        d_neg = np.sqrt(((V - A_neg) ** 2).sum(axis=1))
        denom = d_pos + d_neg
        denom[denom == 0] = 1e-12
        scores = d_neg / denom

        # ── Step 7: rank ──────────────────────────────────────────────────────
        order = np.argsort(-scores)
        ranked = []
        for rank_i, orig_i in enumerate(order, start=1):
            entry = dict(results[orig_i])
            entry["topsis_score"] = float(scores[orig_i])
            entry["rank"]         = rank_i
            ranked.append(entry)

        log.debug("TOPSIS scores: " +
                  str([f"{r['topsis_score']:.4f}" for r in ranked]))
        return ranked

    def score_only(self, results: List[Dict[str, Any]]) -> np.ndarray:
        """Return raw TOPSIS scores (same order as input, not sorted)."""
        if len(results) < 2:
            return np.array([1.0])
        X = self._build_matrix(results)
        norms = np.sqrt((X ** 2).sum(axis=0)); norms[norms == 0] = 1e-12
        V = (X / norms) * np.array([self.weights[k] for k in METRIC_KEYS])
        A_pos = np.array([
            V[:, j].max() if self.impacts[k] == "+" else V[:, j].min()
            for j, k in enumerate(METRIC_KEYS)
        ])
        A_neg = np.array([
            V[:, j].min() if self.impacts[k] == "+" else V[:, j].max()
            for j, k in enumerate(METRIC_KEYS)
        ])
        d_pos = np.sqrt(((V - A_pos) ** 2).sum(1))
        d_neg = np.sqrt(((V - A_neg) ** 2).sum(1))
        denom = d_pos + d_neg; denom[denom == 0] = 1e-12
        return d_neg / denom

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _build_matrix(self, results: List[Dict[str, Any]]) -> np.ndarray:
        rows = [[float(r.get(k, 0.0)) for k in METRIC_KEYS] for r in results]
        return np.array(rows, dtype=np.float64)

    @staticmethod
    def _validate(weights: Dict[str, float], impacts: Dict[str, str]) -> None:
        missing_w = set(METRIC_KEYS) - set(weights)
        missing_i = set(METRIC_KEYS) - set(impacts)
        if missing_w:
            raise ValueError(f"Missing weights for metrics: {missing_w}")
        if missing_i:
            raise ValueError(f"Missing impacts for metrics: {missing_i}")
        total = sum(weights.values())
        if abs(total - 1.0) > 1e-5:
            raise ValueError(f"Weights must sum to 1.0, got {total:.6f}")
        bad = {k: v for k, v in impacts.items() if v not in ("+", "-")}
        if bad:
            raise ValueError(f"Impact must be '+' or '-'. Got: {bad}")
