# TOPSIS-Driven AutoML v2
## Multi-Criteria Framework for Efficient Neural Architecture Search

A comprehensive NAS research framework that evaluates and compares multiple
search strategies across multiple datasets using TOPSIS multi-criteria
decision-making with 7 performance metrics.

---

## Project Structure

```
nas_v2/
│
├── main.py                          # ← Entry point
├── requirements.txt
│
├── datasets/
│   └── loader.py                    # CIFAR-10, MNIST, UCI Wine, UCI BC
│
├── models/
│   └── flexible_cnn.py              # Unified image + tabular CNN
│
├── search/
│   ├── base.py                      # Abstract searcher interface
│   ├── random_search.py             # Uniform random sampling
│   ├── grid_search.py               # Systematic grid enumeration
│   ├── bayesian_search.py           # GP surrogate + UCB acquisition
│   └── topsis_nas.py                # TOPSIS-guided pre-ranking (proposed)
│
├── metrics/
│   ├── trainer.py                   # Full metric collection per model
│   └── collector.py                 # Trains all candidates for one bundle
│
├── topsis/
│   └── ranker.py                    # 7-step TOPSIS (pure NumPy)
│
├── experiments/
│   ├── runner.py                    # Full experiment matrix orchestration
│   └── ablation.py                  # Weight-sensitivity ablation study
│
├── visualization/
│   └── plots.py                     # 7 matplotlib/seaborn plot types
│
├── utils/
│   ├── config.py                    # Master configuration dataclass
│   ├── logger.py                    # Logging setup
│   └── reporter.py                  # Console tables + CSV export
│
└── outputs/                         # Auto-created
    ├── results_<dataset>_<strategy>.csv
    ├── summary.csv
    ├── performance_comparison.png
    ├── metric_comparison.png
    ├── pareto_front.png
    ├── ranking_heatmap.png
    ├── ablation_study.png
    ├── radar_<dataset>.png
    └── score_distribution.png
```

---

## Datasets

| Dataset | Samples | Classes | Type | Source |
|---------|---------|---------|------|--------|
| CIFAR-10 | 60,000 | 10 | Image 32×32 RGB | torchvision |
| MNIST | 70,000 | 10 | Image 28×28 grey | torchvision |
| UCI Wine | 178 | 3 | Tabular (13 features) | sklearn |
| UCI Breast Cancer | 569 | 2 | Tabular (30 features) | sklearn |

---

## Search Strategies

| Strategy | Method | Notes |
|----------|--------|-------|
| **Random** | Uniform sampling without replacement | Baseline |
| **Grid** | Sorted Cartesian product enumeration | Systematic baseline |
| **Bayesian** | GP surrogate + UCB acquisition function | State-of-the-art |
| **TOPSIS-NAS** | Structural proxy pre-ranking via TOPSIS | **Proposed method** |

### Search Space

| Dimension | Options | Size |
|-----------|---------|------|
| `num_conv_layers` | 2, 3, 4 | 3 |
| `num_filters` | 16, 32, 64 | 3 |
| `dropout_rate` | 0.0, 0.3, 0.5 | 3 |
| `use_batchnorm` | True, False | 2 |
| `activation` | relu, leaky_relu, elu | 3 |
| **Total** | | **162** |

---

## Metrics Collected

| Metric | Direction | Weight | How Measured |
|--------|-----------|--------|--------------|
| Accuracy | ↑ max | 0.25 | Test-set fraction correct |
| F1 Score | ↑ max | 0.20 | Macro-averaged F1 |
| Training Time | ↓ min | 0.15 | Wall-clock seconds |
| Memory (MB) | ↓ min | 0.15 | Peak RAM/VRAM delta |
| Num Parameters | ↓ min | 0.10 | Trainable param count |
| Energy (Joules) | ↓ min | 0.10 | Power × time proxy |
| Model Size (KB) | ↓ min | 0.05 | float32 × params / 1024 |

---

## TOPSIS Algorithm

```
Step 1  Build decision matrix  X  [n_alternatives × 7_criteria]
Step 2  Vector-normalise:  r_ij = x_ij / ‖x_j‖₂
Step 3  Apply weights:     v_ij = w_j × r_ij
Step 4  Ideal A+:          max(col) for benefit, min(col) for cost
        Anti-ideal A-:     min(col) for benefit, max(col) for cost
Step 5  Euclidean distances d+_i, d-_i to A+, A-
Step 6  Closeness score:   C_i = d-_i / (d+_i + d-_i)
Step 7  Rank by descending C_i  (1 = best)
```

---

## Visualizations

| File | Description |
|------|-------------|
| `performance_comparison.png` | Grouped bar: best accuracy per dataset × strategy |
| `metric_comparison.png` | 8-panel grid: all metrics averaged across datasets |
| `pareto_front.png` | Accuracy vs parameters scatter with Pareto frontier |
| `ranking_heatmap.png` | TOPSIS score heatmap [dataset × strategy] |
| `ablation_study.png` | Best TOPSIS score under 5 weight configurations |
| `radar_<dataset>.png` | Spider chart: strategies on all 8 metric spokes |
| `score_distribution.png` | Box plots: TOPSIS score spread per strategy |

---

## Ablation Study Weight Configurations

| Label | Accuracy | F1 | Time | Memory | Params | Energy | Size |
|-------|----------|----|------|--------|--------|--------|------|
| Accuracy-Only | 1.0 | 0 | 0 | 0 | 0 | 0 | 0 |
| Accuracy+F1 | 0.5 | 0.5 | 0 | 0 | 0 | 0 | 0 |
| Speed-Focused | 0.2 | 0.1 | 0.4 | 0.2 | 0.1 | 0 | 0 |
| Balanced (Default) | 0.25 | 0.20 | 0.15 | 0.15 | 0.10 | 0.10 | 0.05 |
| Green-AI | 0.20 | 0.15 | 0.10 | 0.10 | 0.05 | 0.35 | 0.05 |

---

## Quick Start

```bash
# Install dependencies
pip install -r requirements.txt

# Run full experiment (downloads CIFAR-10 + MNIST automatically)
python main.py
```

### Faster test run (edit main.py)
```python
cfg.datasets   = ["mnist", "uci_wine"]   # lighter datasets
cfg.strategies = ["random", "topsis_nas"]
cfg.epochs     = 2
cfg.num_random_candidates = 4
```

---

## Configuration Reference (`utils/config.py`)

```python
@dataclass
class Config:
    datasets   = ["cifar10","mnist","uci_wine","uci_breast_cancer"]
    strategies = ["random","grid","bayesian","topsis_nas"]
    epochs     = 3          # training epochs per model
    lr         = 1e-3       # Adam learning rate
    batch_size = 64
    num_random_candidates = 9   # candidates for random/grid/topsis_nas
    num_bayesian_trials   = 9   # iterations for Bayesian search
    seed       = 42
    topsis_weights = { ... }    # 7-key dict, must sum to 1.0
    topsis_impacts = { ... }    # 7-key dict, '+' or '-'
```

---

## Extending the Framework

| Goal | Where |
|------|-------|
| Add a new dataset | `datasets/loader.py` |
| Add a new search strategy | `search/` — subclass `BaseSearcher` |
| Add a new metric | `metrics/trainer.py` + `topsis/ranker.py` → `METRIC_KEYS` |
| Change TOPSIS weights | `utils/config.py` → `TOPSIS_WEIGHTS` |
| Add a new plot | `visualization/plots.py` + call in `main.py` |
| Add more ablation configs | `utils/config.py` → `ablation_weight_sets` |

---

## Citation

```
Hwang, C.L.; Yoon, K. (1981). Multiple Attribute Decision Making:
Methods and Applications. Springer-Verlag.

Elsken, T.; Metzen, J.H.; Hutter, F. (2019). Neural Architecture Search:
A Survey. JMLR 20(55):1−21.
```
