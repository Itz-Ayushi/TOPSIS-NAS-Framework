"""
metrics/collector.py
--------------------
Trains all candidate architectures for a given dataset and returns
the raw result list consumed by the TOPSIS ranker.
"""

import logging
from typing import List, Dict, Any

from torch.utils.data import DataLoader

from models.flexible_cnn import FlexibleCNN
from metrics.trainer import Trainer
from datasets.loader import DatasetBundle

log = logging.getLogger(__name__)


class MetricsCollector:
    """
    Evaluates a list of architecture configs against one DatasetBundle.

    Args:
        bundle: DatasetBundle (train+test loaders + metadata).
        epochs: Training epochs per model.
        lr:     Adam learning rate.
        device: 'cpu' or 'cuda'.
    """

    def __init__(
        self,
        bundle: DatasetBundle,
        epochs: int   = 3,
        lr:     float = 1e-3,
        device: str   = "cpu",
    ) -> None:
        self.bundle  = bundle
        self._trainer = Trainer(
            train_loader=bundle.train_loader,
            test_loader=bundle.test_loader,
            epochs=epochs,
            lr=lr,
            device=device,
        )

    def evaluate_all(
        self, candidates: List[Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        """
        Train every architecture and return enriched result dicts.

        Each result dict contains:
            arch         – original architecture dict
            + all metric keys from Trainer.fit_and_evaluate()
        """
        results = []
        n = len(candidates)

        for idx, arch in enumerate(candidates, 1):
            label = self._arch_label(arch)
            log.info(f"  [{idx:02d}/{n}] {label}")

            model = FlexibleCNN(
                arch=arch,
                input_shape=self.bundle.input_shape,
                num_classes=self.bundle.num_classes,
                dataset_type=self.bundle.dataset_type,
            )

            metrics = self._trainer.fit_and_evaluate(model)
            log.info(
                f"         acc={metrics['accuracy']:.4f}  "
                f"f1={metrics['f1_score']:.4f}  "
                f"t={metrics['train_time']:.1f}s  "
                f"mem={metrics['memory_mb']:.1f}MB  "
                f"params={metrics['num_params']:,}"
            )
            results.append({"arch": arch, **metrics})

        return results

    @staticmethod
    def _arch_label(arch: Dict[str, Any]) -> str:
        return (
            f"Conv×{arch.get('num_conv_layers','?')} "
            f"F{arch.get('num_filters','?')} "
            f"{arch.get('activation','?')} "
            f"BN={arch.get('use_batchnorm','?')} "
            f"drop={arch.get('dropout_rate','?')}"
        )
