"""
metrics/trainer.py
------------------
Trains one model and returns the complete metric bundle:

    accuracy       – fraction correct on test set
    precision      – macro-averaged precision
    recall         – macro-averaged recall
    f1_score       – macro-averaged F1
    train_time     – wall-clock training seconds
    memory_mb      – peak GPU/CPU memory delta during training (MB)
    num_params     – trainable parameter count
    model_size_kb  – float32 parameter size in KB
    energy_joules  – estimated energy via power × time proxy

Energy estimation
~~~~~~~~~~~~~~~~~
True energy measurement requires hardware PMU access (RAPL, NVML).
As a portable proxy we use:
    energy ≈ train_time × estimated_watts
where estimated_watts is derived from the parameter count
(a rough but reproducible surrogate for compute intensity).
"""

import logging
import time
import tracemalloc
from typing import Dict, Any, Tuple

import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from sklearn.metrics import precision_recall_fscore_support

log = logging.getLogger(__name__)

# Proxy: watts per million parameters (empirically ballparked for CPU)
_WATTS_PER_M_PARAMS = 0.05


class Trainer:
    """
    Train-and-evaluate a single model, returning all metrics.

    Args:
        train_loader: Training DataLoader.
        test_loader:  Test DataLoader.
        epochs:       Training epochs.
        lr:           Adam learning rate.
        device:       'cpu' or 'cuda'.
    """

    def __init__(
        self,
        train_loader: DataLoader,
        test_loader:  DataLoader,
        epochs:       int   = 3,
        lr:           float = 1e-3,
        device:       str   = "cpu",
    ) -> None:
        self.train_loader = train_loader
        self.test_loader  = test_loader
        self.epochs       = epochs
        self.lr           = lr
        self.device       = torch.device(device)

    def fit_and_evaluate(self, model: nn.Module) -> Dict[str, Any]:
        """
        Train *model* and return a full metrics dict.

        Returns:
            Dict with keys:
            accuracy, precision, recall, f1_score,
            train_time, memory_mb, num_params, model_size_kb, energy_joules
        """
        model = model.to(self.device)
        num_params    = sum(p.numel() for p in model.parameters() if p.requires_grad)
        model_size_kb = num_params * 4 / 1024

        criterion = nn.CrossEntropyLoss()
        optimiser = torch.optim.Adam(model.parameters(), lr=self.lr)
        scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
            optimiser, T_max=self.epochs
        )

        # ── Memory tracking ───────────────────────────────────────────────────
        if self.device.type == "cuda":
            torch.cuda.reset_peak_memory_stats(self.device)
            mem_before = torch.cuda.memory_allocated(self.device)
        else:
            tracemalloc.start()

        # ── Training loop ─────────────────────────────────────────────────────
        model.train()
        t0 = time.perf_counter()

        for epoch in range(1, self.epochs + 1):
            total_loss = correct = total = 0
            for xb, yb in self.train_loader:
                xb, yb = xb.to(self.device), yb.to(self.device)
                optimiser.zero_grad(set_to_none=True)
                logits = model(xb)
                loss   = criterion(logits, yb)
                loss.backward()
                optimiser.step()
                total_loss += loss.item() * xb.size(0)
                correct    += (logits.argmax(1) == yb).sum().item()
                total      += yb.size(0)
            scheduler.step()
            log.debug(
                f"    ep {epoch}/{self.epochs}  "
                f"loss={total_loss/total:.4f}  "
                f"train_acc={correct/total:.4f}"
            )

        train_time = time.perf_counter() - t0

        # ── Memory delta ──────────────────────────────────────────────────────
        if self.device.type == "cuda":
            peak = torch.cuda.max_memory_allocated(self.device)
            memory_mb = (peak - mem_before) / 1024 ** 2
        else:
            _, peak_bytes = tracemalloc.get_traced_memory()
            tracemalloc.stop()
            memory_mb = peak_bytes / 1024 ** 2

        # ── Energy proxy ──────────────────────────────────────────────────────
        est_watts     = (num_params / 1e6) * _WATTS_PER_M_PARAMS
        energy_joules = est_watts * train_time

        # ── Evaluation ────────────────────────────────────────────────────────
        accuracy, precision, recall, f1 = self._evaluate(model)

        return {
            "accuracy":      accuracy,
            "precision":     precision,
            "recall":        recall,
            "f1_score":      f1,
            "train_time":    train_time,
            "memory_mb":     max(memory_mb, 0.01),   # avoid zero for TOPSIS norm
            "num_params":    num_params,
            "model_size_kb": model_size_kb,
            "energy_joules": energy_joules,
        }

    def _evaluate(self, model: nn.Module) -> Tuple[float, float, float, float]:
        """Return (accuracy, macro_precision, macro_recall, macro_f1)."""
        model.eval()
        all_preds, all_labels = [], []
        with torch.no_grad():
            for xb, yb in self.test_loader:
                xb = xb.to(self.device)
                preds = model(xb).argmax(1).cpu()
                all_preds.append(preds)
                all_labels.append(yb)

        preds_np  = torch.cat(all_preds).numpy()
        labels_np = torch.cat(all_labels).numpy()

        accuracy = float((preds_np == labels_np).mean())
        prec, rec, f1, _ = precision_recall_fscore_support(
            labels_np, preds_np, average="macro", zero_division=0
        )
        return accuracy, float(prec), float(rec), float(f1)
