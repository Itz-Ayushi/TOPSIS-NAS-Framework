"""
models/flexible_cnn.py
----------------------
Flexible CNN that handles both image and tabular inputs.

Image path  (dataset_type='image'):
    [Conv2d → BN? → Activation → MaxPool] × num_conv_layers
    → AdaptiveAvgPool2d(1) → Flatten
    → FC(filters, 128) → Act → Dropout → FC(128, num_classes)

Tabular path (dataset_type='tabular'):
    Input is (B, 1, 1, n_features).
    A single 1×1 conv projects features to num_filters channels,
    then the same FC head is applied.  This lets one unified class
    handle both data modalities without branching in the trainer.

Search-space dimensions
~~~~~~~~~~~~~~~~~~~~~~~
    num_conv_layers : 2 | 3 | 4
    num_filters     : 16 | 32 | 64
    dropout_rate    : 0.0 | 0.3 | 0.5
    use_batchnorm   : True | False
    activation      : 'relu' | 'leaky_relu' | 'elu'
"""

import logging
from typing import Dict, Any, Tuple

import torch
import torch.nn as nn

log = logging.getLogger(__name__)

_ACT_MAP = {
    "relu":       nn.ReLU,
    "leaky_relu": nn.LeakyReLU,
    "elu":        nn.ELU,
}


def _make_act(name: str) -> nn.Module:
    if name not in _ACT_MAP:
        raise ValueError(f"Unknown activation '{name}'. Choose: {list(_ACT_MAP)}")
    return _ACT_MAP[name](inplace=True) if name == "relu" else _ACT_MAP[name]()


class FlexibleCNN(nn.Module):
    """
    Unified configurable network for image and tabular tasks.

    Args:
        arch:         Architecture dict (from search modules).
        input_shape:  (C, H, W) — for tabular: (1, 1, n_features).
        num_classes:  Number of output classes.
        dataset_type: 'image' | 'tabular'
    """

    def __init__(
        self,
        arch:         Dict[str, Any],
        input_shape:  Tuple[int, ...],
        num_classes:  int,
        dataset_type: str = "image",
    ) -> None:
        super().__init__()

        self.arch         = arch
        self.input_shape  = input_shape
        self.num_classes  = num_classes
        self.dataset_type = dataset_type

        nl   = arch.get("num_conv_layers", 3)
        nf   = arch.get("num_filters",     32)
        dr   = arch.get("dropout_rate",    0.3)
        bn   = arch.get("use_batchnorm",   True)
        act  = arch.get("activation",      "relu")

        in_ch = input_shape[0]

        # ── Feature extractor ─────────────────────────────────────────────────
        layers = []
        if dataset_type == "tabular":
            # 1×1 conv to project n_features → num_filters channels
            layers += [
                nn.Conv2d(in_ch, nf, kernel_size=1, bias=not bn),
                *([] if not bn else [nn.BatchNorm2d(nf)]),
                _make_act(act),
            ]
        else:
            # Standard image conv blocks with progressive depth
            for i in range(nl):
                out_ch = nf
                layers += [
                    nn.Conv2d(in_ch, out_ch, kernel_size=3, padding=1, bias=not bn),
                    *([] if not bn else [nn.BatchNorm2d(out_ch)]),
                    _make_act(act),
                    nn.MaxPool2d(2, 2),
                ]
                in_ch = out_ch

        self.features = nn.Sequential(*layers)
        self.gap       = nn.AdaptiveAvgPool2d(1)

        # ── Classifier head ───────────────────────────────────────────────────
        self.classifier = nn.Sequential(
            nn.Flatten(),
            nn.Linear(nf, 128),
            _make_act(act),
            nn.Dropout(dr),
            nn.Linear(128, num_classes),
        )

        self._init_weights()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.features(x)
        x = self.gap(x)
        return self.classifier(x)

    def count_parameters(self) -> int:
        return sum(p.numel() for p in self.parameters() if p.requires_grad)

    def model_size_kb(self) -> float:
        """Approximate on-disk size as float32 (4 bytes per param)."""
        return self.count_parameters() * 4 / 1024

    def _init_weights(self) -> None:
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode="fan_out", nonlinearity="relu")
            elif isinstance(m, nn.BatchNorm2d):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias,   0)
            elif isinstance(m, nn.Linear):
                nn.init.xavier_uniform_(m.weight)
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)

    def __repr__(self) -> str:
        return (
            f"FlexibleCNN("
            f"layers={self.arch.get('num_conv_layers')}, "
            f"filters={self.arch.get('num_filters')}, "
            f"act={self.arch.get('activation')}, "
            f"bn={self.arch.get('use_batchnorm')}, "
            f"drop={self.arch.get('dropout_rate')}, "
            f"params={self.count_parameters():,})"
        )
